
-- Group Members:
-- Name: [Member 1 Name], RM: [Member 1 RM]
-- Name: [Member 2 Name], RM: [Member 2 RM]
-- Name: [Member 3 Name], RM: [Member 3 RM]

CREATE TABLE T_ENDERECO (
    endereco_logradouro VARCHAR2(100) NOT NULL,
    endereco_numero NUMBER NOT NULL,
    endereco_cep VARCHAR2(10) NOT NULL,
    endereco_bairro VARCHAR2(50) NOT NULL,
    endereco_estado VARCHAR2(2) NOT NULL,
    endereco_cidade VARCHAR2(50) NOT NULL,
    endereco_id INTEGER PRIMARY KEY
);
CREATE TABLE T_CLIENTE (
    cliente_nome VARCHAR2(50) NOT NULL,
    cliente_sobrenome VARCHAR2(50) NOT NULL,
    cliente_idade NUMBER NOT NULL CHECK (cliente_idade > 0 AND cliente_idade < 90),
    cliente_telefone VARCHAR2(15) NOT NULL,
    cliente_cpf VARCHAR2(14) NOT NULL, -- Ajuste para incluir formata��o
    cliente_id INTEGER PRIMARY KEY,
    endereco_id INTEGER,
    CONSTRAINT FK_endereco_ID FOREIGN KEY (endereco_id) REFERENCES T_ENDERECO(endereco_id)
);

CREATE TABLE T_PERFIL (
    perfil_email VARCHAR2(100) NOT NULL, 
    perfil_senha VARCHAR2(100) NOT NULL,
    perfil_nomeUsuario VARCHAR2(50) NOT NULL,
    perfil_IdUsuario NUMBER PRIMARY KEY,
    perfil_id INTEGER,
    CONSTRAINT FK_perfil_id FOREIGN KEY (perfil_id) REFERENCES T_CLIENTE(cliente_id)
);

CREATE TABLE T_PRODUTO (
    produto_nomeProduto VARCHAR2(50) NOT NULL,
    produto_modelo VARCHAR2(50) NOT NULL,
    produto_anoDoModelo NUMBER NOT NULL,
    produto_corDoProduto VARCHAR2(50) NOT NULL,
    produto_IdSerie NUMBER PRIMARY KEY
);

CREATE TABLE T_ORCAMENTO (
    orcamento_id INTEGER PRIMARY KEY, -- Novo ID num�rico
    orcamento_diagnostico VARCHAR2(50) NOT NULL,
    orcamento_comissaoFornecedor VARCHAR2(50) NOT NULL,
    orcamento_comissaoMecanica VARCHAR2(50) NOT NULL
);

CREATE TABLE T_PEDIDO (
    pedido_IdPedido NUMBER PRIMARY KEY,
    pedido_dataPedido DATE NOT NULL,
    pedido_automovel VARCHAR2(50) NOT NULL,
    pedido_orcamento VARCHAR2(50) NOT NULL,
    produto_IdSerie NUMBER NOT NULL,
    orcamento_id INTEGER NOT NULL, -- Alterado para referenciar novo ID em T_ORCAMENTO
    CONSTRAINT FK_orcamento_diagnostico FOREIGN KEY (orcamento_id) REFERENCES T_ORCAMENTO(orcamento_id)
);

INSERT INTO T_ENDERECO (endereco_logradouro, endereco_numero, endereco_cep, endereco_bairro, endereco_estado, endereco_cidade, endereco_id) VALUES ('Rua A', 100, '01234-567', 'Centro', 'SP', 'S�o Paulo', 1);
INSERT INTO T_ENDERECO (endereco_logradouro, endereco_numero, endereco_cep, endereco_bairro, endereco_estado, endereco_cidade, endereco_id) VALUES ('Rua B', 200, '12345-678', 'Jardins', 'SP', 'S�o Paulo', 2);
INSERT INTO T_ENDERECO (endereco_logradouro, endereco_numero, endereco_cep, endereco_bairro, endereco_estado, endereco_cidade, endereco_id) VALUES ('Avenida C', 300, '23456-789', 'Lapa', 'SP', 'S�o Paulo', 3);
INSERT INTO T_ENDERECO (endereco_logradouro, endereco_numero, endereco_cep, endereco_bairro, endereco_estado, endereco_cidade, endereco_id) VALUES ('Rua D', 400, '34567-890', 'Vila Nova', 'SP', 'S�o Paulo', 4);
INSERT INTO T_ENDERECO (endereco_logradouro, endereco_numero, endereco_cep, endereco_bairro, endereco_estado, endereco_cidade, endereco_id) VALUES ('Rua E', 500, '45678-901', 'Morumbi', 'SP', 'S�o Paulo', 5);
INSERT INTO T_ENDERECO (endereco_logradouro, endereco_numero, endereco_cep, endereco_bairro, endereco_estado, endereco_cidade, endereco_id) VALUES ('Rua F', 600, '56789-012', 'Pinheiros', 'SP', 'S�o Paulo', 6);
INSERT INTO T_ENDERECO (endereco_logradouro, endereco_numero, endereco_cep, endereco_bairro, endereco_estado, endereco_cidade, endereco_id) VALUES ('Avenida G', 700, '67890-123', 'Vila Mariana', 'SP', 'S�o Paulo', 7);
INSERT INTO T_ENDERECO (endereco_logradouro, endereco_numero, endereco_cep, endereco_bairro, endereco_estado, endereco_cidade, endereco_id) VALUES ('Rua H', 800, '78901-234', 'Bela Vista', 'SP', 'S�o Paulo', 8);
INSERT INTO T_ENDERECO (endereco_logradouro, endereco_numero, endereco_cep, endereco_bairro, endereco_estado, endereco_cidade, endereco_id) VALUES ('Rua I', 900, '89012-345', 'Liberdade', 'SP', 'S�o Paulo', 9);
INSERT INTO T_ENDERECO (endereco_logradouro, endereco_numero, endereco_cep, endereco_bairro, endereco_estado, endereco_cidade, endereco_id) VALUES ('Rua J', 1000, '90123-456', 'Campo Belo', 'SP', 'S�o Paulo', 10);




INSERT INTO T_CLIENTE (cliente_nome, cliente_sobrenome, cliente_idade, cliente_telefone, cliente_cpf, cliente_id, endereco_id) VALUES ('Jo�o', 'Silva', 28, '(11) 91234-5678', '12345678909', 1, 1);
INSERT INTO T_CLIENTE (cliente_nome, cliente_sobrenome, cliente_idade, cliente_telefone, cliente_cpf, cliente_id, endereco_id) VALUES ('Maria', 'Souza', 35, '(11) 98765-4321', '23456789010', 2, 2);
INSERT INTO T_CLIENTE (cliente_nome, cliente_sobrenome, cliente_idade, cliente_telefone, cliente_cpf, cliente_id, endereco_id) VALUES ('Carlos', 'Pereira', 45, '(11) 99876-5432', '34567890111', 3, 3);
INSERT INTO T_CLIENTE (cliente_nome, cliente_sobrenome, cliente_idade, cliente_telefone, cliente_cpf, cliente_id, endereco_id) VALUES ('Ana', 'Oliveira', 22, '(11) 91234-6789', '45678901212', 4, 4);
INSERT INTO T_CLIENTE (cliente_nome, cliente_sobrenome, cliente_idade, cliente_telefone, cliente_cpf, cliente_id, endereco_id) VALUES ('Lucas', 'Martins', 30, '(11) 92345-6789', '56789012313', 5, 5);
INSERT INTO T_CLIENTE (cliente_nome, cliente_sobrenome, cliente_idade, cliente_telefone, cliente_cpf, cliente_id, endereco_id) VALUES ('Juliana', 'Lima', 40, '(11) 93456-7890', '67890123414', 6, 6);
INSERT INTO T_CLIENTE (cliente_nome, cliente_sobrenome, cliente_idade, cliente_telefone, cliente_cpf, cliente_id, endereco_id) VALUES ('Felipe', 'Gomes', 33, '(11) 94567-8901', '78901234515', 7, 7);
INSERT INTO T_CLIENTE (cliente_nome, cliente_sobrenome, cliente_idade, cliente_telefone, cliente_cpf, cliente_id, endereco_id) VALUES ('Roberta', 'Fernandes', 26, '(11) 95678-9012', '89012345616', 8, 8);
INSERT INTO T_CLIENTE (cliente_nome, cliente_sobrenome, cliente_idade, cliente_telefone, cliente_cpf, cliente_id, endereco_id) VALUES ('Marcos', 'Almeida', 50, '(11) 96789-0123', '90123456717', 9, 9);
INSERT INTO T_CLIENTE (cliente_nome, cliente_sobrenome, cliente_idade, cliente_telefone, cliente_cpf, cliente_id, endereco_id) VALUES ('Paula', 'Ribeiro', 29, '(11) 97890-1234', '01234567818', 10, 10);



INSERT INTO T_PERFIL (cadastro_email, cadastro_senha, cadastro_nomeUsuario, cadastro_IdUsuario, cliente_id) VALUES ('joao.silva@email.com', 'senha123', 'joaosilva', 1, 1);
INSERT INTO T_PERFIL (cadastro_email, cadastro_senha, cadastro_nomeUsuario, cadastro_IdUsuario, cliente_id) VALUES ('maria.souza@email.com', 'senha456', 'mariasouza', 2, 2);
INSERT INTO T_PERFIL (cadastro_email, cadastro_senha, cadastro_nomeUsuario, cadastro_IdUsuario, cliente_id) VALUES ('carlos.pereira@email.com', 'senha789', 'carlospereira', 3, 3);
INSERT INTO T_PERFIL (cadastro_email, cadastro_senha, cadastro_nomeUsuario, cadastro_IdUsuario, cliente_id) VALUES ('ana.oliveira@email.com', 'senha101', 'anaoliveira', 4, 4);
INSERT INTO T_PERFIL (cadastro_email, cadastro_senha, cadastro_nomeUsuario, cadastro_IdUsuario, cliente_id) VALUES ('lucas.martins@email.com', 'senha112', 'lucasmartins', 5, 5);
INSERT INTO T_PERFIL (cadastro_email, cadastro_senha, cadastro_nomeUsuario, cadastro_IdUsuario, cliente_id) VALUES ('juliana.lima@email.com', 'senha113', 'julianalima', 6, 6);
INSERT INTO T_PERFIL (cadastro_email, cadastro_senha, cadastro_nomeUsuario, cadastro_IdUsuario, cliente_id) VALUES ('felipe.gomes@email.com', 'senha114', 'felipegomes', 7, 7);
INSERT INTO T_PERFIL (cadastro_email, cadastro_senha, cadastro_nomeUsuario, cadastro_IdUsuario, cliente_id) VALUES ('roberta.fernandes@email.com', 'senha115', 'robertafernandes', 8, 8);
INSERT INTO T_PERFIL (cadastro_email, cadastro_senha, cadastro_nomeUsuario, cadastro_IdUsuario, cliente_id) VALUES ('marcos.almeida@email.com', 'senha116', 'marcosalmeida', 9, 9);
INSERT INTO T_PERFIL (cadastro_email, cadastro_senha, cadastro_nomeUsuario, cadastro_IdUsuario, cliente_id) VALUES ('paula.ribeiro@email.com', 'senha117', 'paularibeiro', 10, 10);



INSERT INTO T_PRODUTO (produto_nomeProduto, produto_modelo, produto_anoDoModelo, produto_corDoProduto, produto_IdSerie) VALUES ('Fusca', 'Classic', 1970, 'Azul', 1);
INSERT INTO T_PRODUTO (produto_nomeProduto, produto_modelo, produto_anoDoModelo, produto_corDoProduto, produto_IdSerie) VALUES ('Civic', 'LX', 2020, 'Preto', 2);
INSERT INTO T_PRODUTO (produto_nomeProduto, produto_modelo, produto_anoDoModelo, produto_corDoProduto, produto_IdSerie) VALUES ('Corolla', 'XEI', 2021, 'Branco', 3);
INSERT INTO T_PRODUTO (produto_nomeProduto, produto_modelo, produto_anoDoModelo, produto_corDoProduto, produto_IdSerie) VALUES ('Palio', 'Sport', 2019, 'Vermelho', 4);
INSERT INTO T_PRODUTO (produto_nomeProduto, produto_modelo, produto_anoDoModelo, produto_corDoProduto, produto_IdSerie) VALUES ('Onix', 'LT', 2022, 'Prata', 5);
INSERT INTO T_PRODUTO (produto_nomeProduto, produto_modelo, produto_anoDoModelo, produto_corDoProduto, produto_IdSerie) VALUES ('HR-V', 'EX', 2023, 'Cinza', 6);
INSERT INTO T_PRODUTO (produto_nomeProduto, produto_modelo, produto_anoDoModelo, produto_corDoProduto, produto_IdSerie) VALUES ('Captur', 'Intense', 2018, 'Bege', 7);
INSERT INTO T_PRODUTO (produto_nomeProduto, produto_modelo, produto_anoDoModelo, produto_corDoProduto, produto_IdSerie) VALUES ('Renegade', 'Longitude', 2020, 'Verde', 8);
INSERT INTO T_PRODUTO (produto_nomeProduto, produto_modelo, produto_anoDoModelo, produto_corDoProduto, produto_IdSerie) VALUES ('Tucson', 'Ultimate', 2021, 'Azul', 9);
INSERT INTO T_PRODUTO (produto_nomeProduto, produto_modelo, produto_anoDoModelo, produto_corDoProduto, produto_IdSerie) VALUES ('Compass', 'S', 2022, 'Branco', 10);


INSERT INTO T_ORCAMENTO (orcamento_id, orcamento_diagnostico, orcamento_comissaoFornecedor, orcamento_comissaoMecanica) VALUES (1, 'Troca de �leo', '10%', '15%');
INSERT INTO T_ORCAMENTO (orcamento_id, orcamento_diagnostico, orcamento_comissaoFornecedor, orcamento_comissaoMecanica) VALUES (2, 'Revis�o Completa', '12%', '18%');
INSERT INTO T_ORCAMENTO (orcamento_id, orcamento_diagnostico, orcamento_comissaoFornecedor, orcamento_comissaoMecanica) VALUES (3, 'Desempenho do Motor', '8%', '10%');
INSERT INTO T_ORCAMENTO (orcamento_id, orcamento_diagnostico, orcamento_comissaoFornecedor, orcamento_comissaoMecanica) VALUES (4, 'Troca de Pneus', '5%', '20%');
INSERT INTO T_ORCAMENTO (orcamento_id, orcamento_diagnostico, orcamento_comissaoFornecedor, orcamento_comissaoMecanica) VALUES (5, 'Alinhamento', '7%', '13%');
INSERT INTO T_ORCAMENTO (orcamento_id, orcamento_diagnostico, orcamento_comissaoFornecedor, orcamento_comissaoMecanica) VALUES (6, 'Suspens�o', '9%', '12%');
INSERT INTO T_ORCAMENTO (orcamento_id, orcamento_diagnostico, orcamento_comissaoFornecedor, orcamento_comissaoMecanica) VALUES (7, 'Freios', '6%', '10%');
INSERT INTO T_ORCAMENTO (orcamento_id, orcamento_diagnostico, orcamento_comissaoFornecedor, orcamento_comissaoMecanica) VALUES (8, 'Bateria', '11%', '15%');
INSERT INTO T_ORCAMENTO (orcamento_id, orcamento_diagnostico, orcamento_comissaoFornecedor, orcamento_comissaoMecanica) VALUES (9, 'Sistema El�trico', '8%', '14%');
INSERT INTO T_ORCAMENTO (orcamento_id, orcamento_diagnostico, orcamento_comissaoFornecedor, orcamento_comissaoMecanica) VALUES (10, 'Ar Condicionado', '9%', '16%');
INSERT INTO T_ORCAMENTO (orcamento_id, orcamento_diagnostico, orcamento_comissaoFornecedor, orcamento_comissaoMecanica) VALUES (11, 'Troca de Filtro', '7%', '13%');
INSERT INTO T_ORCAMENTO (orcamento_id, orcamento_diagnostico, orcamento_comissaoFornecedor, orcamento_comissaoMecanica) VALUES (12, 'Lavagem Completa', '5%', '10%');
INSERT INTO T_ORCAMENTO (orcamento_id, orcamento_diagnostico, orcamento_comissaoFornecedor, orcamento_comissaoMecanica) VALUES (13, 'Inspe��o Veicular', '6%', '12%');
INSERT INTO T_ORCAMENTO (orcamento_id, orcamento_diagnostico, orcamento_comissaoFornecedor, orcamento_comissaoMecanica) VALUES (14, 'Verifica��o de Flu�dos', '10%', '15%');
INSERT INTO T_ORCAMENTO (orcamento_id, orcamento_diagnostico, orcamento_comissaoFornecedor, orcamento_comissaoMecanica) VALUES (15, 'Manuten��o Preventiva', '8%', '11%');
INSERT INTO T_ORCAMENTO (orcamento_id, orcamento_diagnostico, orcamento_comissaoFornecedor, orcamento_comissaoMecanica) VALUES (16, 'Manuten��o Corretiva', '7%', '12%');
INSERT INTO T_ORCAMENTO (orcamento_id, orcamento_diagnostico, orcamento_comissaoFornecedor, orcamento_comissaoMecanica) VALUES (17, 'Troca de Correia', '9%', '14%');
INSERT INTO T_ORCAMENTO (orcamento_id, orcamento_diagnostico, orcamento_comissaoFornecedor, orcamento_comissaoMecanica) VALUES (18, 'Calibra��o', '6%', '13%');
INSERT INTO T_ORCAMENTO (orcamento_id, orcamento_diagnostico, orcamento_comissaoFornecedor, orcamento_comissaoMecanica) VALUES (19, 'Ajuste de Suspens�o', '5%', '10%');
INSERT INTO T_ORCAMENTO (orcamento_id, orcamento_diagnostico, orcamento_comissaoFornecedor, orcamento_comissaoMecanica) VALUES (20, 'Teste de Emiss�o', '8%', '12%');


INSERT INTO T_PEDIDO (pedido_IdPedido, pedido_dataPedido, pedido_automovel, pedido_orcamento, produto_IdSerie, orcamento_id) VALUES (1, TO_DATE('2024-01-01', 'YYYY-MM-DD'), 'Fusca', 'Troca de �leo', 1, 1);
INSERT INTO T_PEDIDO (pedido_IdPedido, pedido_dataPedido, pedido_automovel, pedido_orcamento, produto_IdSerie, orcamento_id) VALUES (2, TO_DATE('2024-01-05', 'YYYY-MM-DD'), 'Civic', 'Revis�o Completa', 2, 2);
INSERT INTO T_PEDIDO (pedido_IdPedido, pedido_dataPedido, pedido_automovel, pedido_orcamento, produto_IdSerie, orcamento_id) VALUES (3, TO_DATE('2024-01-10', 'YYYY-MM-DD'), 'Corolla', 'Desempenho do Motor', 3, 3);
INSERT INTO T_PEDIDO (pedido_IdPedido, pedido_dataPedido, pedido_automovel, pedido_orcamento, produto_IdSerie, orcamento_id) VALUES (4, TO_DATE('2024-01-15', 'YYYY-MM-DD'), 'Palio', 'Troca de Pneus', 4, 4);
INSERT INTO T_PEDIDO (pedido_IdPedido, pedido_dataPedido, pedido_automovel, pedido_orcamento, produto_IdSerie, orcamento_id) VALUES (5, TO_DATE('2024-01-20', 'YYYY-MM-DD'), 'Onix', 'Alinhamento', 5, 5);
INSERT INTO T_PEDIDO (pedido_IdPedido, pedido_dataPedido, pedido_automovel, pedido_orcamento, produto_IdSerie, orcamento_id) VALUES (6, TO_DATE('2024-01-25', 'YYYY-MM-DD'), 'HR-V', 'Suspens�o', 6, 6);
INSERT INTO T_PEDIDO (pedido_IdPedido, pedido_dataPedido, pedido_automovel, pedido_orcamento, produto_IdSerie, orcamento_id) VALUES (7, TO_DATE('2024-02-01', 'YYYY-MM-DD'), 'Captur', 'Freios', 7, 7);
INSERT INTO T_PEDIDO (pedido_IdPedido, pedido_dataPedido, pedido_automovel, pedido_orcamento, produto_IdSerie, orcamento_id) VALUES (8, TO_DATE('2024-02-05', 'YYYY-MM-DD'), 'Renegade', 'Bateria', 8, 8);
INSERT INTO T_PEDIDO (pedido_IdPedido, pedido_dataPedido, pedido_automovel, pedido_orcamento, produto_IdSerie, orcamento_id) VALUES (9, TO_DATE('2024-02-10', 'YYYY-MM-DD'), 'Tucson', 'Sistema El�trico', 9, 9);
INSERT INTO T_PEDIDO (pedido_IdPedido, pedido_dataPedido, pedido_automovel, pedido_orcamento, produto_IdSerie, orcamento_id) VALUES (10, TO_DATE('2024-02-15', 'YYYY-MM-DD'), 'Compass', 'Ar Condicionado', 10, 10);
INSERT INTO T_PEDIDO (pedido_IdPedido, pedido_dataPedido, pedido_automovel, pedido_orcamento, produto_IdSerie, orcamento_id) VALUES (11, TO_DATE('2024-02-20', 'YYYY-MM-DD'), 'Fusca', 'Troca de Filtro', 1, 11);
INSERT INTO T_PEDIDO (pedido_IdPedido, pedido_dataPedido, pedido_automovel, pedido_orcamento, produto_IdSerie, orcamento_id) VALUES (12, TO_DATE('2024-02-25', 'YYYY-MM-DD'), 'Civic', 'Lavagem Completa', 2, 12);
INSERT INTO T_PEDIDO (pedido_IdPedido, pedido_dataPedido, pedido_automovel, pedido_orcamento, produto_IdSerie, orcamento_id) VALUES (13, TO_DATE('2024-03-01', 'YYYY-MM-DD'), 'Corolla', 'Inspe��o Veicular', 3, 13);
INSERT INTO T_PEDIDO (pedido_IdPedido, pedido_dataPedido, pedido_automovel, pedido_orcamento, produto_IdSerie, orcamento_id) VALUES (14, TO_DATE('2024-03-05', 'YYYY-MM-DD'), 'Palio', 'Verifica��o de Flu�dos', 4, 14);
INSERT INTO T_PEDIDO (pedido_IdPedido, pedido_dataPedido, pedido_automovel, pedido_orcamento, produto_IdSerie, orcamento_id) VALUES (15, TO_DATE('2024-03-10', 'YYYY-MM-DD'), 'Onix', 'Manuten��o Preventiva', 5, 15);
INSERT INTO T_PEDIDO (pedido_IdPedido, pedido_dataPedido, pedido_automovel, pedido_orcamento, produto_IdSerie, orcamento_id) VALUES (16, TO_DATE('2024-03-15', 'YYYY-MM-DD'), 'HR-V', 'Manuten��o Corretiva', 6, 16);
INSERT INTO T_PEDIDO (pedido_IdPedido, pedido_dataPedido, pedido_automovel, pedido_orcamento, produto_IdSerie, orcamento_id) VALUES (17, TO_DATE('2024-03-20', 'YYYY-MM-DD'), 'Captur', 'Troca de Correia', 7, 17);
INSERT INTO T_PEDIDO (pedido_IdPedido, pedido_dataPedido, pedido_automovel, pedido_orcamento, produto_IdSerie, orcamento_id) VALUES (18, TO_DATE('2024-03-25', 'YYYY-MM-DD'), 'Renegade', 'Calibra��o', 8, 18);
INSERT INTO T_PEDIDO (pedido_IdPedido, pedido_dataPedido, pedido_automovel, pedido_orcamento, produto_IdSerie, orcamento_id) VALUES (19, TO_DATE('2024-03-30', 'YYYY-MM-DD'), 'Tucson', 'Ajuste de Suspens�o', 9, 19);
INSERT INTO T_PEDIDO (pedido_IdPedido, pedido_dataPedido, pedido_automovel, pedido_orcamento, produto_IdSerie, orcamento_id) VALUES (20, TO_DATE('2024-04-01', 'YYYY-MM-DD'), 'Compass', 'Teste de Emiss�o', 10, 20);



SELECT cliente_nome, cliente_sobrenome, cliente_idade
FROM T_CLIENTE
ORDER BY cliente_idade DESC;

SELECT nome_produto, preco
FROM produtos
ORDER BY preco DESC;


SELECT COUNT(*) AS total_clients
FROM T_CLIENTE;

SELECT AVG(idade) AS media_idade
FROM funcionarios;


SELECT endereco_cidade, COUNT(cliente_id) AS clients_per_city
FROM T_CLIENTE
JOIN T_ENDERECO ON T_CLIENTE.endereco_id = T_ENDERECO.endereco_id
GROUP BY endereco_cidade;

SELECT categoria, COUNT(*) AS quantidade_produtos
FROM produtos
GROUP BY categoria;


SELECT cliente_nome, cliente_sobrenome, cliente_idade
FROM T_CLIENTE
WHERE cliente_idade > (SELECT AVG(cliente_idade) FROM T_CLIENTE);

SELECT nome_produto
FROM produtos
WHERE estoque < (SELECT AVG(estoque) FROM produtos);


SELECT cliente_nome, cliente_sobrenome, cliente_idade, endereco_logradouro, endereco_cidade, endereco_estado
FROM T_CLIENTE
JOIN T_ENDERECO ON T_CLIENTE.endereco_id = T_ENDERECO.endereco_id;

SELECT funcionarios.nome_funcionario, departamentos.nome_departamento
FROM funcionarios
JOIN departamentos ON funcionarios.departamento_id = departamentos.departamento_id;


-- Integrantes--
-- Tiago Augusto Desiderato Ferro RM558485 --
-- Celso Canaveze Teixeira Pinto RM556118
-- Thiago Moreno Matheus RM554507